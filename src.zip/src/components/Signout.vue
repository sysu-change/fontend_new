<template>
    <div>
    </div>    
</template>

<script>
export default {
    name:'Signout'
}
</script>

<style scoped>

</style>
